﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlat : MonoBehaviour
{

    public float moveSpeedX = 2f;
    bool directionRight = true;

    void Update()
    {
        if (transform.position.x > 4.5f)
            directionRight = false;
        if (transform.position.x < -4.5f)
            directionRight = true;

        if (directionRight)
            transform.position = new Vector2(transform.position.x + moveSpeedX * Time.deltaTime, transform.position.y);
        else
            transform.position = new Vector2(transform.position.x - moveSpeedX * Time.deltaTime, transform.position.y);
    }
}
