﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScoreManager : MonoBehaviour
{
    public NodeDetect nodeDetect;
    public int score;
    public int totalNodes;
    public Text scoreText;
    public Button nextSceneButton;



    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        nextSceneButton.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
       scoreText.text = score + "/" + totalNodes + " orbs collected";
        if (score == totalNodes)
        {
            nextSceneButton.gameObject.SetActive(true);
        }
    }
    public void LoadNextScene()
    {
        Scene sceneLoaded = SceneManager.GetActiveScene();
        SceneManager.LoadScene(sceneLoaded.buildIndex + 1);
    }

    public void ReloadScene()
    {
        Scene sceneLoaded = SceneManager.GetActiveScene();
        SceneManager.LoadScene(sceneLoaded.buildIndex);
    }
    public void FirstSceneLoad()
    {
        SceneManager.LoadScene("GameLevel1");
    }
}
