﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceDetect : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        GameObject[] nodes = GameObject.FindGameObjectsWithTag("Node");
        Destroy(gameObject);
    }
}
