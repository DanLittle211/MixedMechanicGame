﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MovePlayer : MonoBehaviour
{

    private Vector2 target;

    void Start()
    {
        target = transform.position;
    }


    void Update()
    {
        Vector2 direction = Vector2.zero;
        bool stationary = ((Vector2)transform.position == target);

        if (Input.GetKeyDown(KeyCode.LeftArrow) && stationary)
        {
            direction = new Vector2(-1, 0);
        }

        else if (Input.GetKeyDown(KeyCode.RightArrow) && stationary)
        {
            direction = new Vector2(1, 0);
        }

        else if (Input.GetKeyDown(KeyCode.DownArrow) && stationary)
        {
            direction = new Vector2(0, -1);
        }

        else if (Input.GetKeyDown(KeyCode.UpArrow) && stationary)
        {
            direction = new Vector2(0, 1);
        }
        else
        {
            direction = new Vector2(0, 0);
        }

        RaycastHit2D move = Physics2D.Raycast(transform.position, direction);

        Debug.DrawLine(transform.position, transform.position + (Vector3)direction, Color.blue);
        if (move.collider != null)
        {
            if (move.collider.tag == "Node")
            {
                target = move.transform.position;
            }
        }
        transform.position = Vector2.Lerp(transform.position, target, 0.5f);
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Death")
        {
            Debug.Log("Hit");
            Destroy(this.gameObject);
        }
    }
}
