﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlatY : MonoBehaviour
{
    public float move, moveSpeedY = 2f;
    bool directionUp = true;

    void Update()
    {
        if (transform.position.y > 4f)
            directionUp = false;
        if (transform.position.y < -4f)
            directionUp = true;

        if (directionUp)
            transform.position = new Vector2(transform.position.x, transform.position.y + moveSpeedY * Time.deltaTime);
        else
            transform.position = new Vector2(transform.position.x, transform.position.y - moveSpeedY * Time.deltaTime);
    }
}